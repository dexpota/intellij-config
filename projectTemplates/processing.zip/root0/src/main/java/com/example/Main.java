package ${IJ_BASE_PACKAGE};

import processing.core.PApplet;

public class Main {
    public static void main(String[] args) {
        PApplet.main(ProcessingApplication.class, args);
    }
}
