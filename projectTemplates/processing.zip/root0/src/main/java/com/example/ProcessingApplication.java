package ${IJ_BASE_PACKAGE};

import processing.core.PApplet;

public class ProcessingApplication extends PApplet {
    @Override
    public void settings() {
        super.settings();
    }

    @Override
    public void setup() {
        super.setup();
    }

    @Override
    public void draw() {
        super.draw();
    }
}
